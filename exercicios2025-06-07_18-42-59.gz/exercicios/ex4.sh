#!/usr/bin/env bash
set -eou pipefail

source_directory=$1
[[ -d "$source_directory" ]] || { echo "Invalidy directory"; exit 1; }
destination_directory=$2
[[ -d "$destination_directory" ]] || { echo "Invalidy directory"; exit 1; }

file_name=$source_directory$(date +%Y-%m-%d_%H-%M-%S)".gz"

tar -czf "$file_name" "$source_directory"