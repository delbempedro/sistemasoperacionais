#este é um script em BASH
fruta="banana"
quantia=5

echo "Fruta : $fruta"
echo "quantidade de frutas : $quantia"

