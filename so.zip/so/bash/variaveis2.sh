read -p "Digite A: " a
read -p "Digite B: " b
c=$(( $a+$b ))
echo "A + B = $c"
echo "$a + $b = $c"
