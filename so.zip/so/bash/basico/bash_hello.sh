#!/usr/bin/env bash
set -euo pipefail
######################
######Hello world:
######################
NOME="Fulano"
echo "Olá, ${NOME}!"